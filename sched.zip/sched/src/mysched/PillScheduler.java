package mysched;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import appenv.util.JsonUtils;

public class PillScheduler {

	public enum SchedState {
		INIT, WAIT, ACTIVE, COMPLETED;
	}
	
	private SchedState schedState=SchedState.INIT;
	private JsonObject conf;

	long startDateMs;		// start time for the current schedule
	
	/*
	 * two variables to track things
	 */
	long currentIteration;	// whats out current iteration 
	long dispenseAtMs;		// current dispence time: [dispenseAtMs-wakeBeforeMs , dispenseAtMs+waitAfterMs]
	
	
	/*
	 * parsed parameters
	 */
	long intervalMs;
	long wakeBeforeMs;
	long waitAfterMs;
	long numOfTreatments;
	
	public PillScheduler(JsonObject conf) throws Exception {
		this.conf=conf;
		init();
	}
	private synchronized void init() throws Exception {
		long nowMs=System.currentTimeMillis();
		String strStartDate=JsonUtils.getString(conf, "startDate");
		if (strStartDate!=null) {
			SimpleDateFormat localDateTimeFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date startDate=localDateTimeFormat.parse(strStartDate);
			startDateMs=startDate.getTime();
		} else startDateMs=nowMs;
			
		double intervalHrs=JsonUtils.getNumber(conf, "intervalHrs").doubleValue();
		double wakeBeforeHrs=JsonUtils.getNumber(conf, "wakeBeforeHrs").doubleValue();
		double waitAfterHrs=JsonUtils.getNumber(conf, "waitAfterHrs").doubleValue();
		
		intervalMs=(long) (3600*1000*intervalHrs);
		wakeBeforeMs=(long) (3600*1000*wakeBeforeHrs);
		waitAfterMs=(long) (3600*1000*waitAfterHrs);
		
		Long nt = JsonUtils.getLong(conf, "numOfTreatments");
		numOfTreatments = (nt==null)? 1000000000L : nt.longValue();
		
		
	}
	
	private void readyForDispense() {
		System.out.println("Hello, its time to take yours next doze of meds, press the button");
		
	}
	public synchronized void userGotMeds() {
		if (schedState==SchedState.ACTIVE) {
			System.out.println("User got meds!");
			userGotTheMeds=true;
			notify();
		} else {
			System.out.println("Igoring keypress");
		}
	}
	
	boolean userGotTheMeds=false;
	
	public static class Escalation {
		long ms;
		String type;
		String message;
		Escalation(long ms, String type, String message) {
			this.ms=ms;
			this.type=type;
			this.message=message;
		}
		public String toString() {
			return new Date(ms).toString()+" "+type+" "+message;
		}
	}
	TreeMap<Long, Escalation> msToEscalation=new TreeMap<>();
	private void generateEscalations() {
		msToEscalation.clear();
		long startOfNext=dispenseAtMs-wakeBeforeMs;
		msToEscalation.put(startOfNext, new Escalation(startOfNext, "START", "Its a begining of the new meds dispensing iteration - "+new Date(startOfNext)));
		long midOfNext=dispenseAtMs-wakeBeforeMs/2;
		msToEscalation.put(midOfNext, new Escalation(midOfNext, "REMINER", "Dont forget to take your meds!"));
		msToEscalation.put(dispenseAtMs,new Escalation(dispenseAtMs, "DUETIME", "Its due time to press the button  - "+new Date(dispenseAtMs)));
		long pastDue=dispenseAtMs + waitAfterMs/2;
		msToEscalation.put(pastDue,new Escalation(pastDue, "PASTDUE", "Please take the meds, you are past due"));
		long end=dispenseAtMs + waitAfterMs;
		msToEscalation.put(end,new Escalation(end, "MISSED", "You have missed you meds and will be reported"));
	}
	private void cleanEscalations(long nowMs) {
		for (Iterator<Entry<Long, Escalation>> it = msToEscalation.entrySet().iterator(); it.hasNext();) {
			Entry<Long, Escalation> entry = it.next();
			long atMs=entry.getKey();
			if (atMs<nowMs) it.remove();
		}	
	}
	
	private boolean handleInitState(long nowMs) {
		// lets figure out our current iteration
		if (nowMs>startDateMs) {
			// we are in the middle
			long numCompletedIterations=(nowMs - startDateMs) / intervalMs;
			
			if (numCompletedIterations > numOfTreatments) {
				schedState=SchedState.COMPLETED;
				return false;
			}
			long nextTimeMs= nowMs+(numCompletedIterations+1)*intervalMs;
			if (nowMs > nextTimeMs-wakeBeforeMs) {
				// we are in active state for the next dispense
				schedState=SchedState.ACTIVE;
				currentIteration=numCompletedIterations+1;
			} else if (nowMs < startDateMs + numCompletedIterations* intervalMs+waitAfterMs) {
				// we are at the tail end of the previous dispense 
				schedState=SchedState.ACTIVE;
				currentIteration=numCompletedIterations;
			} else {
				// we are in the middle
				schedState=SchedState.WAIT;
				currentIteration=numCompletedIterations+1;
			}

		} else {
			schedState=SchedState.WAIT;
			currentIteration=0;
		}
		dispenseAtMs=startDateMs+currentIteration*intervalMs;
		System.out.println("Log: From INIT state to " +schedState+ ", current "+new Date(nowMs)+" next dispense "+new Date(dispenseAtMs));
		
		if (schedState==SchedState.ACTIVE) {
			generateEscalations();
			cleanEscalations(nowMs);
		}
		return true;
	}
	
	private boolean handleWaitState(long nowMs) throws InterruptedException {
		if (nowMs>=dispenseAtMs-wakeBeforeMs) {
			System.out.println("Log: WAIT state, current "+new Date(nowMs)+" greater then "+new Date(dispenseAtMs-wakeBeforeMs));
			schedState=SchedState.ACTIVE;
			generateEscalations(); // WAIT->ACTIVE transition
			long nextMs=msToEscalation.isEmpty()?dispenseAtMs-wakeBeforeMs : msToEscalation.firstKey();
			System.out.println("Log: Waiting for the next escalation change till "+new Date(nextMs));
			long ms=nextMs-nowMs;
			if (ms>0) {
				System.out.println("Log: waiting "+ms+" ms.");
				wait(ms); 
			}
		} else {
			System.out.println("Log: WAIT state, current "+new Date(nowMs)+" less then "+new Date(dispenseAtMs-wakeBeforeMs));
			System.out.println("Log: Next dispense at "+new Date(dispenseAtMs));
			System.out.println("Log: Will start bugging patient at  "+new Date(dispenseAtMs-wakeBeforeMs));
			
			long ms=dispenseAtMs-wakeBeforeMs-nowMs;
			if (ms>0) {
				System.out.println("Log: waiting "+ms+" ms.");
				wait(ms); 
			}
		}
		return true;
	}
	
	private boolean handleActiveState(long nowMs) throws InterruptedException {
		System.out.println("Log: ACTIVE state, current time "+new Date(nowMs));
		// We might have reentered here, because we were interrupted by user getting the meds
		if (userGotTheMeds) {
			System.out.println("Log: ACTIVE state, user got meds "+new Date(nowMs));
			// User got the meds, success, reset, and wait till next iteration
			userGotTheMeds=false; // reset meds status
			currentIteration++;
			dispenseAtMs+=intervalMs; // set timer to the next dispense
			schedState=SchedState.WAIT;
			System.out.println("Log: ACTIVE state, reset to WAIT till "+new Date(dispenseAtMs-wakeBeforeMs));
			
			long ms=dispenseAtMs-wakeBeforeMs-nowMs;
			if (ms>0) {
				System.out.println("Log: waiting "+ms+" ms.");
				wait(ms);
			}
		} else {
			// user still didnt get the meds
			// cleanup/signal past-due escalations
			for (Iterator<Entry<Long, Escalation>> it = msToEscalation.entrySet().iterator(); it.hasNext();) {
				Entry<Long, Escalation> entry = it.next();
				long atMs=entry.getKey();
				Escalation escalation=entry.getValue();
				if (atMs>nowMs) break;
				if (atMs<=nowMs) {
					it.remove();
					signalEscalation(escalation);
				}
			}
			if (nowMs >= dispenseAtMs+waitAfterMs) {
				// out of active phase, user didnt get the meds
				schedState=SchedState.WAIT;
				currentIteration++;
				dispenseAtMs+=intervalMs; // set timer to the next dispense
				long ms=dispenseAtMs-wakeBeforeMs-nowMs;
				System.out.println("Log: Timeout for ACTIVE state, reset to WAIT till "+new Date(dispenseAtMs-wakeBeforeMs));
				if (ms>0) {
					System.out.println("Log: waiting "+ms+" ms.");
					wait(ms);
				}
				return true;
			}
			long nextWakeupMs = msToEscalation.isEmpty() ? dispenseAtMs+waitAfterMs :  msToEscalation.firstKey();
			long ms=nextWakeupMs-nowMs;
			System.out.println("Log: ACTIVE state, still active, till "+new Date(nextWakeupMs));
			if (ms>0) {
				System.out.println("Log: waiting "+ms+" ms.");
				wait(ms);
			}
			// Do we still
		}
		return true;
	}
	
	synchronized boolean step() throws Exception {
		long nowMs=System.currentTimeMillis();
		System.out.println("Log: entered with "+schedState+ " at "+new Date(nowMs));
		if (schedState==SchedState.INIT) {
			return handleInitState(nowMs);
		} else if (schedState==SchedState.COMPLETED) {
			return false;
		} else if (schedState==SchedState.WAIT) {
			return handleWaitState(nowMs);
		} else if (schedState==SchedState.ACTIVE) {
			return handleActiveState(nowMs);
		} else {
			throw new RuntimeException("Invalid state"+ schedState); 
		}
	}


	private void signalEscalation(Escalation e) {
		System.out.println("Escalation! type: "+e.type+"; message: "+e.message);
		
	}
	public static void main(String[] args) throws Exception {
		JsonElement sched=null;
		try (InputStream is = PillScheduler.class.getClassLoader().getResourceAsStream("mysched/sched.json") ) {
			sched=JsonParser.parseReader(new InputStreamReader(is));
			System.out.println(sched);
		}
		PillScheduler s=new PillScheduler(sched.getAsJsonObject());
		
		ExecutorService ex = Executors.newCachedThreadPool();
		ex.submit(new Callable<Void>() {
			@Override
			public Void call() throws Exception {
				while (s.step());
				return null;
			}
		});
        int c;
        while ((c = System.in.read()) != -1)
        {
            if (c != '\n' && c != '\r') {
            	char ch=(char)c;
            	System.out.println("Processing: '" + (char)ch + "'");
            	if (ch=='d') s.userGotMeds();
            	
            }
        }
	}

}
