package mysched;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;


import mysched.MyPillScheduler.SchedState;

enum Color {
	red, blue, white, green
}

public class T1 {

	public static void main(String[] args) {
		Color c=Color.blue;
		SchedState a = MyPillScheduler.SchedState.ACTIVE;
		
		TreeMap<Long, String> m=new TreeMap<>();
		
		List<Color> l=new ArrayList<>();
		l.add(c);
		l.add(c);
		l.add(Color.green);
		System.out.println(l);

		if (c==Color.white) {
			
		}
		switch (c) {
		case blue:
			
			break;
		case red:

		default:
			break;
		}
	}

}
